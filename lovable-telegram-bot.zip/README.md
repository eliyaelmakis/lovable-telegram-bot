
# Lovable Telegram Bot

This is a simple Telegram bot connected to Lovable (or OpenAI).
It receives user messages, sends them to your AI backend, and replies with results.

## How to run

1. Add your TELEGRAM_TOKEN and LOVABLE_API as environment variables.
2. Deploy on Render.
3. Set your Telegram webhook to point to your Render URL + `/webhook`.

Enjoy!
